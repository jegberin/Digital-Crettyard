# Design System Document

## 1. Overview & Creative North Star: The Precision Architect
This design system is built upon the "Precision Architect" creative north star. It moves beyond the standard IT services template by blending the structural authority of Navy Blue with the fluid, forward-thinking energy of Teal. Unlike generic systems that rely on rigid grids and heavy borders, this system utilizes high-contrast typography and intentional white space to guide the eye.

The experience is defined by a "Digital Editorial" aesthetic—spacious, premium, and calm. We break the mold through **asymmetrical balance**: placing large, bold display type against expansive empty gutters to create a sense of scale and technical sophistication.

## 2. Colors
Our palette is rooted in depth and clarity. We use the Navy and Teal tokens not just for decoration, but as functional anchors for the user's journey.

### Color Tokens
- **Primary (Teal):** `#1DB48F` / `primary` token. Used for high-value actions and focal points.
- **Secondary (Navy):** `#002157` / `secondary` token. Used for authoritative headings and deep backgrounds.
- **Surface Scale:** Utilizing `surface-container-lowest` (#ffffff) through `surface-container-highest` (#e1e3e4).

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections or modules. Structural boundaries must be achieved through background color shifts. A `surface-container-low` section should sit adjacent to a `surface` background to create a clean, modern break without the visual "noise" of lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of layered, physical materials. 
- **Nesting:** Place a `surface-container-lowest` card inside a `surface-container-low` section to create natural lift. 
- **Glass & Gradient Rule:** For hero sections or primary CTAs, use a subtle linear gradient transitioning from `primary` to `on-primary-container`. For floating navigation or modal overlays, apply `backdrop-blur` (12px-20px) to semi-transparent surface tokens to create a "frosted glass" effect that integrates the UI with the background.

## 3. Typography
We use a dual-font strategy to balance technical precision with human accessibility.

*   **Display & Headlines (Manrope):** Bold, geometric, and authoritative. The wide apertures of Manrope convey a modern, technical expertise. Use `display-lg` for hero statements to command attention.
*   **Body & Labels (Inter):** The industry standard for readability. Inter’s tall x-height ensures that complex IT service descriptions remain legible even at smaller scales.

**Hierarchy as Identity:** Use high-contrast scaling. Pair a massive `display-md` headline in Navy with a significantly smaller `body-md` description in `on-surface-variant`. This "Editorial Gap" creates a premium feel that standard layouts lack.

## 4. Elevation & Depth
Depth in this system is a result of light and layer, not just shadows.

*   **The Layering Principle:** Avoid "Drop Shadow" defaults. Depth is achieved by stacking surface-container tiers. A "raised" element is simply a lighter surface token sitting on a darker one.
*   **Ambient Shadows:** Where a floating effect is necessary (e.g., a primary CTA button or a lead-gen card), use the following:
    *   **Blur:** 24px - 40px.
    *   **Opacity:** 4% - 6%.
    *   **Color:** Use a tinted version of `on-surface` (Navy-tinted) rather than pure grey to mimic natural environmental light.
*   **The "Ghost Border" Fallback:** If a container requires a border for accessibility, use the `outline-variant` token at **15% opacity**. High-contrast, 100% opaque borders are strictly forbidden.

## 5. Components

### Buttons
*   **Primary:** `primary` background with `on-primary` text. Use `rounded-full` (9999px) for a modern, "pill" aesthetic that softens the technical Navy headings.
*   **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
*   **Interaction:** On hover, primary buttons should utilize a subtle `surface-tint` overlay rather than a color change to maintain brand integrity.

### Input Fields
*   **Style:** No background fill; use a 1px "Ghost Border" (outline-variant at 20%). 
*   **States:** On focus, the border transitions to 2px `primary` (Teal) with a subtle glow effect (ambient shadow).

### Cards & Lists
*   **Rule:** Forbid the use of divider lines. 
*   **Implementation:** Separate list items using `spacing-4` (1.4rem) of vertical white space or by alternating background tones between `surface-container-lowest` and `surface-container-low`.
*   **Cards:** Use `rounded-xl` (1.5rem) to echo the organic nature of the logo.

### Professional Grid Overlays
To reinforce the "Technical" influence, use a subtle "Dot Matrix" or "Soft Grid" background pattern (as seen in the reference images) using the `outline-variant` at 5% opacity. This provides a "blueprint" feel to the background.

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical layouts where text is weighted to one side, leaving the other side for breathing room or abstract brand shapes.
*   **Do** use the Spacing Scale strictly (increments of 0.7rem/1.4rem) to ensure the "spacious" feel remains mathematically consistent.
*   **Do** use Navy (`secondary`) for all primary headings to establish authority.

### Don't
*   **Don't** use black (#000000). Always use `on-surface` or `secondary` for text.
*   **Don't** use standard "Box Shadows." If it looks like a 2010s web element, increase the blur and decrease the opacity.
*   **Don't** crowd components. If a section feels "busy," double the padding using the `20` or `24` spacing tokens.